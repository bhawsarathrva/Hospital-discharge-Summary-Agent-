## DIAGNOSIS:

## 1) ACUTE GASTROENTERITIS WITH DEHYDRATION
2) URINARY TRACT INFECTION

HISTORY: C/O Multiple episodes of loose stools, 2-3 episodes of vomiting, fatigue since 3 days and fever since yesterday. Initially she was treated at local clinic.

PAST HISTORY:K/C/O Thyroid disorder on treatment.

PHYSICAL EXAMINATION:

PR-89/min, BP-130/80 mmHg, RR-20/min, SPO2-98% at room air.
CNS-Conscious Oriented
CVS-S1S2(+)
RS-B/L NVBS(+)
PA-Soft, non tender

## INVESTIGATIONS:

Reports Enclosed

## COURSE IN THE HOSPITAL:

Patient presented to us with above mentioned complaints. After evaluation, she
was admitted to ward. Initial investigations showed normal CBC. Serum
creatinine (1.65mg/dl) done was elevated. Serum electrolytes done showed low
serum sodium(128.00mnol/L). Urine routine done showed ketone bodies(+), 10-
12/hpf of pus cells, 15-20/hpf of epithelial cells with presence of bactreia hence
urine culture and sensitivity sent- report awaited. She was treated with IV fluids,